<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();
?>
        <!-- header -->
        <section class="breadcrumbs-custom" style="background: url(&quot;images/grad_cover.png&quot;); background-size: cover;">
          <div class="container">
            <p class="heading-1 breadcrumbs-custom-title" style="color:#C0C0C0">About Us</p>
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.php" style="color:white">Home</a></li>
              <li class="active" style="color:white">About Us</li>
            </ul>
          </div>
        </section>

      <!-- Definition -->
      <section class="section section-lg bg-default">
        <div class="container container-bigger">
          <div class="row row-50 justify-content-md-center align-items-lg-center justify-content-xl-between flex-lg-row-reverse">
            <div class="col-md-10 col-lg-6 col-xl-5">
              <h3>Welcome to EventSpot,</h3>
              <div class="divider divider-decorate"></div>
              <p class="heading-5">our go-to platform for academic events in Jordan. We connect students with a wide range of opportunities, from scientific conferences and workshops to networking events and study groups.</p>
              <p class="text-spacing-sm">Our mission is to foster a vibrant academic community where learning, collaboration, and personal growth thrive. Join us to enrich your academic journey and unlock new opportunities for success. </p>
              <a class="button button-default-outline button-nina" href="contacts.php">Contact Us</a>
            </div>
            <div class="col-md-10 col-lg-6"><img src="images/study_group.jpg" alt="" width="720" height="459"/>
            </div>
          </div>
        </div>
      </section>

      <!-- Small Features-->
      <section class="section section-lg section-lg-alternative bg-gray-lighter novi-background bg-cover">
        <div class="container container-wide">
          <div class="row row-50 justify-content-sm-center text-gray-light">
            <div class="col-sm-10 col-md-6 col-xl-3">
              <article class="box-minimal">
                <div class="box-minimal-header">
                  <div class="box-minimal-icon box-minimal-icon-lg novi-icon mdi mdi mdi-airplane"></div>
                  <h6 class="box-minimal-title">Exchange Programs</h6>
                </div>
                <p>Embark on a journey of cultural exchange and academic exploration with our student exchange programs, opening doors to new perspectives and unforgettable experiences.</p>
              </article>
            </div>
            <div class="col-sm-10 col-md-6 col-xl-3">
              <article class="box-minimal">
                <div class="box-minimal-header">
                  <div class="box-minimal-icon box-minimal-icon-lg novi-icon mdi mdi-map"></div>
                  <h6 class="box-minimal-title">Lectures & Resources</h6>
                </div>
                <p>Discover new resources for your materials, providing nerdy notes and talks for your academic journey.</p>
              </article>
            </div>
            <div class="col-sm-10 col-md-6 col-xl-3">
              <article class="box-minimal">
                <div class="box-minimal-header">
                  <div class="box-minimal-icon box-minimal-icon-lg novi-icon mdi mdi-city"></div>
                  <h6 class="box-minimal-title">Conferences</h6>
                </div>
                <p>Experience the thrill of discovery at our upcoming conference, where knowledge meets inspiration in an engaging environment designed to fuel your academic journey.</p>
              </article>
            </div>
            <div class="col-sm-10 col-md-6 col-xl-3">
              <article class="box-minimal">
                <div class="box-minimal-header">
                  <div class="box-minimal-icon box-minimal-icon-lg novi-icon mdi mdi-beach"></div>
                  <h6 class="box-minimal-title">Social Meetups</h6>
                </div>
                <p>Join students for networking and community-building, fostering connections beyond the classroom.</p>
              </article>
            </div>
          </div>
        </div>
      </section>

    
     
<?php
include_once("includes/footer.php");
?>