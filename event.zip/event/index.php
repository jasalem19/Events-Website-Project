<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();
?>
      <section class="section">
        <div class="swiper-form-wrap">
          <!-- Swiper-->
          <div class="swiper-container swiper-slider swiper-slider_height-1 swiper-align-left swiper-align-left-custom context-dark bg-gray-darker" data-loop="false" data-autoplay="5500" data-simulate-touch="false" data-slide-effect="fade">
            <div class="swiper-wrapper">
              <div class="swiper-slide" data-slide-bg="images/science_forum.jpg">
                <div class="swiper-slide-caption">
                  <div class="container container-bigger swiper-main-section">
                    <div class="row row-fix justify-content-sm-center justify-content-md-start">
                      <div class="col-md-6 col-lg-5 col-xl-4 col-xxl-5">
                        <h3>Tens of Conferences!</h3>
                        <div class="divider divider-decorate"></div>
                        <p class="text-spacing-sm">Discover upcoming conferences, where knowledge meets inspiration in an engaging environment designed to fuel your academic journey.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide" data-slide-bg="images/JEEIT.jpg">
                <div class="swiper-slide-caption">
                  <div class="container container-bigger swiper-main-section">
                    <div class="row row-fix justify-content-sm-center justify-content-md-start">
                      <div class="col-md-6 col-lg-5 col-xl-4 col-xxl-5">
                        <h3>Hundreds of Competitions!</h3>
                        <div class="divider divider-decorate"></div>
                        <p class="text-spacing-sm">Test your skills against fellow students. Participate to challenge yourself, gain experience, and enjoy the thrill of competing in a supportive community.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide" data-slide-bg="images/queen_rania.png">
                <div class="swiper-slide-caption">
                  <div class="container container-bigger swiper-main-section">
                  <div class="row row-fix justify-content-sm-center justify-content-md-start">
                      <div class="col-md-6 col-lg-5 col-xl-4 col-xxl-5">
                        <h3>Discover All Academic Events in Jordan!</h3>
                        <div class="divider divider-decorate"></div>
                        <p class="text-spacing-sm">Join students for networking and community-building, fostering connections beyond the classroom.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="container container-bigger form-request-wrap form-request-wrap-modern">
            <div class="row row-fix justify-content-sm-center justify-content-lg-end">
              <div class="col-lg-6 col-xxl-5">
                <div class="form-request form-request-modern bg-gray-lighter novi-background">
                    <div class="row row-20 row-fix">
                      <div class="col-sm-12">
                          <label class="form-label-outside">Category</label>
                          <div class="form-wrap form-wrap-inline">
    <select class="form-input select-filter" data-placeholder="All" data-minimum-results-for-search="Infinity" name="category" id="categorySelect">
        <?php
        $query = "SELECT * FROM categories";
        $result = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            $category_id = $row['category_id'];
            $category_name = $row['category_name'];
            echo "<option value='$category_id'>$category_name</option>";
        }
        ?>
    </select>
    <button type="button" class="col-xl-3 button button-secondary button-nina" onclick="redirectToCategory()">find Events</button>
</div>

<script>
    function redirectToCategory() {
        var categoryId = document.getElementById('categorySelect').value;
        if (categoryId) {
            window.location.href = 'category.php?category_id=' + encodeURIComponent(categoryId);
        }
    }
</script>


</div>

                      </div>
                    </div>
 <!--
                  <form class="rd-mailform form-fix" action="search_events.php" method="GET">
                    <div class="row row-20 row-fix">
                        <div class="col-sm-12">
                            <hr divider>
                            <div class="col-sm-12 col-lg-6">
                                <div class="form-wrap form-wrap-validation">
                                    <input class="form-input" type="text" id="search" name="search" placeholder="Search...">
                                </div>
                            </div>
                            <div class="col-sm-12 col-lg-6">
                                <div class="form-wrap form-wrap-validation">
                                    <button class="button button-block button-secondary" type="submit">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                  </form>

                          <label class="form-label-outside">Category</label>
                          <div class="form-wrap form-wrap-inline">
                              <select class="form-input select-filter" data-placeholder="All" data-minimum-results-for-search="Infinity" name="category">
                                  <option value="1">Conference</option>
                                  <option value="2">Workshop</option>
                                  <option value="3">Lecture</option>
                                  <option value="4">Networking</option>
                                  <option value="5">Volunteering</option>
                                  <option value="6">Hackathon</option>
                                  <option value="7">Sport</option>
                                  <option value="8">Study group</option>
                              </select>
                          </div>
                      </div>
                      <div class="col-sm-12 col-lg-6">
                          <label class="form-label-outside">Date</label>
                          <div class="form-wrap form-wrap-validation">
                              <input class="form-input" id="dateForm" name="date" type="text" data-time-picker="date">
                              <label class="form-label" for="dateForm">Choose date</label>
                          </div>
                      </div> 
                      </div>
                  </form> -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section section-variant-1 bg-default novi-background bg-cover"> 
        <div class="container container-wide">
          <div class="row row-fix justify-content-xl-end row-30 text-center text-xl-left">
            <div class="col-xl-8">
              <div class="parallax-text-wrap">
                <h3>Recent events</h3><span class="parallax-text">Event Spot</span>
              </div>
              <hr class="divider divider-decorate">
            </div>
            <div class="col-xl-3 text-xl-right"><a class="button button-secondary button-nina" href="all_events.php">View All Events</a></div>
          </div>
        <div class="row row-50">
        <?php 
    // Prepare query to fetch the 6 most recent events
    $query = "SELECT events.*, users.user_name 
              FROM events 
              JOIN users ON events.user_id = users.user_id
              ORDER BY events.event_start_time DESC 
              LIMIT 6";

    $result = mysqli_query($conn, $query);

// Function to format datetime
function formatTime($datetime) {
  return date('h:i A ', strtotime($datetime));
}
function formatDate($datetime) {
  return date('d M', strtotime($datetime));
}
    
    // Check if there are events found
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="col-md-6 col-xl-4">
                <article class="event-default-wrap">
                    <div class="event-default">
                        <figure class="event-default-image">
                            <img src="events_control_panel/images/<?php echo htmlspecialchars($row['event_image']); ?>" alt="" width="570" height="370"/>
                        </figure>
                        <div class="event-default-caption">
                            <a class="button button-xs button-secondary button-nina" href="details.php?event_id=<?php echo intval($row['event_id']); ?>">More details</a>
                        </div>
                    </div>
                    <div class="event-default-inner">
                        <h5 class="event-default-title"><?php echo htmlspecialchars($row['event_title']); ?></h5>
                        <span class="heading-5"><?php echo htmlspecialchars($row['user_name']); ?></span>
                    </div>
                    <div>
                    <hr class="divider">
                    <div class="post-blog-caption-inner">
                      <time datetime="2019"><?php echo formatDate($row['event_start_time']) ?> - <?php echo formatDate($row['event_end_time']) ?></time>
                      <i class="fa fa-calendar icon-md-middle icon-gray-1 mdi col-xl-9  text-xl-right"></i>
                    </div>
                    <div class="post-blog-caption-inner">
                      <time datetime="2019"><?php echo formatTime($row['event_start_time']) ?> - <?php echo formatTime($row['event_end_time']) ?></time>
                    </div>
                  </div>
                </article>
            </div>
            <?php 
        }
    } else {
        echo '<div class="col-12"><p>No events found.</p></div>';
    }

    // Free result set
    mysqli_free_result($result);
?>


        </div>
    </div>
</section>



      <section class="section section-lg text-center bg-gray-lighter novi-background bg-cover">
        <div class="container container-bigger">
          <div class="divider divider-decorate"></div>
          <!-- Owl Carousel-->
          <div class="owl-carousel owl-layout-1" data-items="1" data-dots="true" data-nav="true" data-stage-padding="0" data-loop="true" data-margin="30" data-mouse-drag="false" data-autoplay="true">
            <article class="quote-boxed">
              <div class="quote-boxed-aside"><img class="quote-boxed-image" src="images/queen_rania_1.jpg" alt="" width="210" height="210"/>
              </div>
              <div class="quote-boxed-main">
                <div class="quote-boxed-text">
                  <pre>يجب علينا جميعا أن نتشارك في تطوير التعليم في الأردن، والتطوير 
! يعني أن نستبدل أساليب الأمس بما يتناسب مع متطلبات الغد </pre>
                </div>
                <div class="quote-boxed-meta">
                  <p class="quote-boxed-cite">Queen Rania</p>
                </div>
              </div>
            </article>
            <article class="quote-boxed">
              <div class="quote-boxed-aside"><img class="quote-boxed-image" src="images/hult1.png" alt="" width="210" height="210"/>
              </div>
              <div class="quote-boxed-main">
                <div class="quote-boxed-text">
                  <p>“Hult Prize was truly the turning point from being regular students to becoming social entrepreneurs"</p>
                </div>
                <div class="quote-boxed-meta">
                  <p class="quote-boxed-cite"> Abu Safieh Abu Safieh,</p>
                  <p class="quote-boxed-small">One of The Hult Prize Winner</p>
                </div>
              </div>
            </article>
            <article class="quote-boxed">
              <div class="quote-boxed-aside"><img class="quote-boxed-image" src="images/teacher.png" alt="" width="210" height="210"/>
              </div>
              <div class="quote-boxed-main">
                <div class="quote-boxed-text">
                <pre>تجربتي مع جمعية جائزة الملكة رانيا العبدالله للتميز التربوي
ساهمت في نشر مشاعر السعادة والإنجاز في حياتي ! أنا أتطلع لأن أكون سفيرة
 تنشر ثقافة التميز في مجال التعليم في الأردن الحبيب </pre>
               </div>
                <div class="quote-boxed-meta">
                  <p class="quote-boxed-cite"> أمل الصوفي</p>
                  <p class="quote-boxed-small">فائزة في المرتبة الثالثة في جائزة المعلم المتميز</p>
                </div>
              </div>
            </article>
          </div>
        </div>
      </section>
<?php 
include_once("includes/footer.php");
?>

