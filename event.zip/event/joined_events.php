<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
session_start();
?>


<section class="section section-variant-1 bg-default novi-background bg-cover"> 
            <div class="container container-wide">
              <div class="row row-fix justify-content-xl-end row-30 text-center text-xl-left">
                <div class="col-xl-8">
                  <div class="parallax-text-wrap">
                  <h3>joined events</h3>
                  </div>
                  <hr class="divider">
                </div>
                <div class="col-xl-3 text-xl-right"></div>
              </div>
            <div class="row row-50">
            <?php 

        $query = "SELECT * 
        FROM events 
        JOIN users ON events.user_id = users.user_id 
        JOIN tickets ON events.event_id = tickets.event_id 
        WHERE tickets.user_id = {$_SESSION['user_id']}";

$result = mysqli_query($conn, $query);
    
    // Function to format datetime
    function formatTime($datetime) {
      return date('h:i A ', strtotime($datetime));
    }
    function formatDate($datetime) {
      return date('d M', strtotime($datetime));
    }
        
        // Check if there are events found
        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <div class="col-md-6 col-xl-4">
                    <article class="event-default-wrap">
                        <div class="event-default">
                            <figure class="event-default-image">
                                <img src="events_control_panel/images/<?php echo htmlspecialchars($row['event_image']); ?>" alt="" width="570" height="370"/>
                            </figure>
                            <div class="event-default-caption">
                                <a class="button button-xs button-secondary button-nina" href="details.php?event_id=<?php echo intval($row['event_id']); ?>">More details</a>
                            </div>
                        </div>
                        <div class="event-default-inner">
                            <h5 class="event-default-title"><?php echo htmlspecialchars($row['event_title']); ?></h5>
                            <span class="heading-5"><?php echo htmlspecialchars($row['user_name']); ?></span>
                        </div>
                        <div>
                    <hr class="divider">
                    <div class="post-blog-caption-inner">
                      <time datetime="2019"><?php echo formatDate($row['event_start_time']) ?> - <?php echo formatDate($row['event_end_time']) ?></time>
                      <i class="fa fa-calendar icon-md-middle icon-gray-1 mdi col-xl-9  text-xl-right"></i>
                    </div>
                    <div class="post-blog-caption-inner">
                      <time datetime="2019"><?php echo formatTime($row['event_start_time']) ?> - <?php echo formatTime($row['event_end_time']) ?></time>
                    </div>
                  </div>
                    </article>
                </div>
                <?php 
            }
        } else {
            echo '<div class="col-12"><p>No events found.</p></div>';
        }
    
        // Free result set
        mysqli_free_result($result);
    ?>
    
    
            </div>
        </div>
    </section>
<?php 
include_once("includes/footer.php");
?>
