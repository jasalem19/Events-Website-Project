<?php
include_once("includes/dbconn.php");   
error_reporting(0);
session_start();

    $query="INSERT INTO tickets(`event_id`, `user_id`)
    VALUES('{$_GET['event_id']}','{$_SESSION['user_id']}')";
    mysqli_query($conn,$query);
    echo "<script>alert('Your seat reservation has been completed successfully.')</script>";

    echo "<script> window.location.href='joined_events.php';</script>";

?>
