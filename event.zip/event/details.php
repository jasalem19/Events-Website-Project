
<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();

// Function to check if the user has already joined the event
function hasUserJoinedEvent($conn, $event_id, $user_id) {
    $query = "SELECT * FROM tickets WHERE event_id = $event_id AND user_id = $user_id";
    $result = mysqli_query($conn, $query);
    return mysqli_num_rows($result) > 0;
}

$query = "SELECT * FROM events 
          JOIN users ON events.user_id = users.user_id 
          JOIN categories ON categories.category_id = events.category_id 
          WHERE events.event_id = {$_GET['event_id']}";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

// Function to format datetime
function formatDateTime($datetime) {
    return date('M d, Y h:i A', strtotime($datetime));
}

?>

<section class="section section-lg novi-background bg-cover bg-default text-center">
    <div class="container-wide">
        <div class="row">
            <div class="col-lg-12">
                <h3><?php echo $row['category_name'] ?></h3>
                <article class="post-blog">
                    <a class="post-blog-image" href="#">
                        <img src="events_control_panel/images/<?php echo $row['event_image'] ?>" alt="" width="570" height="415"/>
                    </a>
                    <div class="post-blog-caption">
                        <div class="post-blog-caption-header">
                            <ul class="post-blog-tags">
                                <li><span class="heading-5"><?php echo $row['event_title'] ?></span></li>
                            </ul>
                            <ul class="post-blog-meta">
                                <li><span>by</span>&nbsp;<span style="color:#ffa900"><?php echo $row['user_name'] ?></span></li>
                            </ul>
                        </div>
                        <div class="post-blog-caption-body">
                            <h5><?php echo $row['event_description'] ?></h5>
                        </div>
                        <div class="post-blog-caption-footer">
                            <time datetime="2019"><?php echo $row['event_address'] ?></time>
                            <a class="post-comment" href="<?php echo $row['event_location'] ?>" target="_blank">
                                <span class="icon novi-icon icon-md-middle icon-gray-1 mdi mdi-map-marker post-blog-title"></span>
                            </a>
                        </div>
                        <div class="post-blog-caption-footer">
                            <time datetime="2019"><?php echo formatDateTime($row['event_start_time']) ?> - <?php echo formatDateTime($row['event_end_time']) ?></time>
                            <i class="fa fa-calendar icon-md-middle icon-gray-1 mdi"></i>
                            <?php 
                            if (isset($_SESSION['user_id'])) {
                                // Check if the user has already joined this event
                                if (hasUserJoinedEvent($conn, $_GET['event_id'], $_SESSION['user_id'])) { 
                                    // User has joined, show a different button
                                    ?>
                                <?php } else { ?>
                                    <!-- User has not joined, show the Join button -->
                                    <a class="post-comment" href="sent_event.php?event_id=<?php echo $row['event_id'] ?>">
                                        <button class="button button-secondary button-nina" style="background-color:#252525;" type="button" name="btn_user">Join</button>
                                    </a>
                                <?php } ?>
                            <?php } else { ?>
                                <!-- User not logged in, show disabled Join button -->
                                <a class="post-comment disabled-button" href="#" title="Log In to Join">
                                    <button class="button" style="background-color:#C0C0C0;" type="button" name="btn_user" disabled>Join</button>
                                </a>
                            <?php } ?>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section>

<?php 
include_once("includes/footer.php");
?>
