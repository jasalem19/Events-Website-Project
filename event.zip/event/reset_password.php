<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();

if (isset($_POST['btn_send_reset_link'])) {
    $email = $_POST['user_email'];

    // Check if the email exists in the database
    $query = "SELECT * FROM users WHERE user_email = ?";
    if ($stmt = mysqli_prepare($conn, $query)) {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        if ($row) {
            // Generate a unique reset token
            $resetToken = bin2hex(random_bytes(32));

            // Store the reset token along with the email in a database or some storage mechanism

            // Send the reset link via email
            $to = $email;
            $subject = "Password Reset Request";
            $message = "Click the following link to reset your password: http://yourwebsite.com/reset_password.php?token=$resetToken";
            $headers = "From: your@example.com" . "\r\n" .
                "Reply-To: your@example.com" . "\r\n" .
                "X-Mailer: PHP/" . phpversion();

            // Send the email
            if (mail($to, $subject, $message, $headers)) {
                echo "<script>alert('Reset link sent successfully. Please check your email.')</script>";
            } else {
                echo "<script>alert('Error sending reset link. Please try again later.')</script>";
            }
        } else {
            echo "<script>alert('Email not found. Please enter a valid email.')</script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('There was an error with the query.')</script>";
    }
}
?>

<section class="section section-lg bg-default">
    <div class="container container-bigger">
        <div class="row row-50 justify-content-md-center align-items-lg-center justify-content-xl-between flex-lg-row-reverse">
            <div class="col-md-10 col-lg-6 col-xl-5">
                <form method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-email"></label>
                                <input class="form-input" id="form-1-email" type="email" name="user_email" placeholder="E-mail" required />
                            </div>
                        </div>
                        <div class="col-sm-12 offset-custom-1">
                            <div class="form-button">
                                <button class="button button-secondary button-nina" style="background-color:#252525;" type="submit" name="btn_send_reset_link">Send Reset Link</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-10 col-lg-6">
                <img src="images/study_group.jpg" alt="" width="720" height="459" />
            </div>
        </div>
    </div>
</section>

<?php
include_once("includes/footer.php");
?>
