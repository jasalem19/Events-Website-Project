<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_POST['btn_Login'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        echo "<script>alert('Invalid CSRF token. Please try again.');</script>";
        exit;
    }

    $email = filter_var($_POST['user_email'], FILTER_SANITIZE_EMAIL); 
    $password = trim($_POST['user_password']);

    $query = "SELECT * FROM users WHERE user_email = ?";
    if ($stmt = mysqli_prepare($conn, $query)) {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        if ($row && isset($row['user_password']) && password_verify($password, $row['user_password'])) {
            session_regenerate_id(true); 
            $_SESSION['user_id'] = $row['user_id'];
            echo "<script>alert('You Logged In Successfully.')</script>";
            echo "<script>window.location.href='index.php';</script>";
            exit;
        } else {
            echo "<script>alert('The email and password are invalid.')</script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        error_log("Prepared statement failed: " . mysqli_error($conn));
        echo "<script>alert('There was an error with the query.')</script>";
        exit; 
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
<section class="section section-lg bg-default">
    <div class="container container-bigger">
        <div class="row row-50 justify-content-md-center align-items-lg-center justify-content-xl-between flex-lg-row-reverse">
            <div class="col-md-10 col-lg-6 col-xl-5">
                <form method="post" action="login.php" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-email"></label>
                                <input class="form-input" id="form-1-email" type="email" name="user_email" placeholder="E-mail" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-phone"></label>
                                <input class="form-input" type="password" name="user_password" placeholder="Password" id="password" onkeyup="validatePassword()" required />
                                <span id="password-error" style="color: red;"></span>
                            </div>
                            <a href="reset_password.php">Forgot Password?</a>
                        </div>
                        <div class="col-sm-12 offset-custom-1">
                            <div class="form-button">
                                <button class="button button-secondary button-nina" style="background-color:#252525;" type="submit" name="btn_Login">Login</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-10 col-lg-6">
                <img src="images/study_group.jpg" alt="" width="720" height="459" />
            </div>
        </div>
    </div>
</section>

<?php
include_once("includes/footer.php");
?>
</body>
</html>
