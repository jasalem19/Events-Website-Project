<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting(0);
session_start();

$id = intval($_GET['edit_id']); // Ensure $id is an integer

if (isset($_POST['btn_user'])) {
    $user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
    $user_email = mysqli_real_escape_string($conn, $_POST['user_email']);
    $user_address = mysqli_real_escape_string($conn, $_POST['user_address']);
    $user_phone = mysqli_real_escape_string($conn, $_POST['user_phone']);
    $user_password = $_POST['user_password'];
    $user_confirm_password = $_POST['user_confirm_password'];

    // Fetch the current password from the database
    $stmt = $conn->prepare("SELECT user_password FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 0) {
        echo "<script>alert('User not found.');</script>";
        echo "<script> window.location.href='profile.php';</script>";
        exit();
    }
    $row = $result->fetch_assoc();
    $current_password = $row['user_password'];

    // Check if the password field was modified and if both password fields match
    if (!empty($user_password)) {
        if ($user_password === $user_confirm_password) {
            if (password_verify($user_password, $current_password)) {
                $hashed_password = $current_password; // Password not changed
            } else {
                $hashed_password = password_hash($user_password, PASSWORD_DEFAULT); // Hash the new password
            }
        } else {
            echo "<script>alert('Passwords do not match. Please try again.')</script>";
            echo "<script> window.location.href='edit_profile.php?edit_id=$id';</script>";
            exit();
        }
    } else {
        $hashed_password = $current_password;
    }

    // Update the user data in the database
    $stmt = $conn->prepare("UPDATE users SET user_name = ?, user_email = ?, user_address = ?, user_phone = ?, user_password = ? WHERE user_id = ?");
    $stmt->bind_param("sssssi", $user_name, $user_email, $user_address, $user_phone, $hashed_password, $id);
    if ($stmt->execute()) {
        echo "<script>alert('Profile was updated successfully.')</script>";
        echo "<script> window.location.href='profile.php';</script>";
    } else {
        echo "<script>alert('Failed to update profile.')</script>";
        echo "<script> window.location.href='edit_profile.php?edit_id=$id';</script>";
    }
}

$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
?>

<section class="section section-lg bg-default">
    <div class="container container-bigger">
        <div class="row row-50 justify-content-md-center align-items-lg-center justify-content-xl-between flex-lg-row-reverse">
            <div class="col-md-10 col-lg-12 col-xl-12">
                <form method="post" enctype="multipart/form-data" onsubmit="return validatePasswords()">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-name"></label>
                                <input class="form-input" id="form-1-name" type="text" name="user_name" value="<?php echo htmlspecialchars($row['user_name']); ?>" placeholder="Full Name" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-email"></label>
                                <input class="form-input" id="form-1-email" type="email" name="user_email" value="<?php echo htmlspecialchars($row['user_email']); ?>" placeholder="E-mail" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-address"></label>
                                <input class="form-input" id="form-1-address" type="text" name="user_address" value="<?php echo htmlspecialchars($row['user_address']); ?>" placeholder="User Address" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-phone"></label>
                                <input class="form-input" id="form-1-phone" pattern="[0-9]{10}" type="tel" value="<?php echo htmlspecialchars($row['user_phone']); ?>" placeholder="User Phone" name="user_phone" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-password"></label>
                                <input class="form-input" type="password" name="user_password" placeholder="New Password" id="password" onkeyup="validatePassword()" />
                                <span id="password-error" style="color: red;"></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-confirm-password"></label>
                                <input class="form-input" type="password" name="user_confirm_password" placeholder="Confirm New Password" id="confirm_password" />
                                <span id="confirm-password-error" style="color: red;"></span>
                            </div>
                        </div>
                        <div class="col-sm-12 offset-custom-1">
                            <div class="form-button">
                                <button class="button button-sm button-secondary button-nina" type="submit" name="btn_user">Update</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<script>
function validatePassword() {
    var password = document.getElementById("password").value;

    if (password.length < 8) {
        document.getElementById("password-error").innerText = "Password must contain at least 8 characters.";
        return false;
    } else {
        document.getElementById("password-error").innerText = "";

        var uppercase = /[A-Z]/;
        var symbol = /[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?]+/;

        if (!uppercase.test(password) || !symbol.test(password)) {
            document.getElementById("password-error").innerText = "The password must contain an uppercase letter and a symbol.";
            return false;
        } else {
            document.getElementById("password-error").innerText = "";
        }
    }

    return true;
}

function validatePasswords() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm_password").value;

    if (password !== confirmPassword) {
        document.getElementById("confirm-password-error").innerText = "Passwords do not match.";
        return false;
    }

    return true;
}
</script>

<?php
include_once("includes/footer.php");
?>
