<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
session_start();

$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$stmt->close();
?>

<div class="container rounded bg-white mt-5 mb-5">
    <div class="row" style="margin-top:125px;">
        <div class="col-md-3 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <img class="rounded-circle mt-5" width="150px" src="images/profile_picture.png" alt="Profile Picture">
                <span class="font-weight-bold"><?php echo $row['user_name']; ?></span>
                <span class="text-black-50"><?php echo $row['user_email']; ?></span>
            </div>
        </div>
        <div class="col-md-5 border-right">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Personal Information</h4>
                </div>
                <hr>
                <div class="row mt-2">
                    <div class="col-md-6">Full Name:</div>
                    <div class="col-md-6"><?php echo $row['user_name']; ?></div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6">Email:</div>
                    <div class="col-md-6"><?php echo $row['user_email']; ?></div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">Address:</div>
                    <div class="col-md-6"><?php echo $row['user_address']; ?></div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">Phone:</div>
                    <div class="col-md-6"><?php echo str_pad($row['user_phone'], 10, '0', STR_PAD_LEFT); ?></div>
                </div>
                <div class="mt-5 text-center">
                    <a href="edit_profile.php?edit_id=<?php echo $row['user_id']; ?>">
                        <button class="button button-sm button-secondary button-nina" type="button">Edit Profile</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include_once("includes/footer.php");
?>
