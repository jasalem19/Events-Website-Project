<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();
?>
    
          

      <section class="section section-variant-1 bg-default novi-background bg-cover"> 
        <div class="container container-wide">
         
          <div class="row row-50">
            <?php 
                $query="select * from events JOIN users where events.user_id=users.user_id AND events.category_id={$_GET['category_id']}";
                $result=mysqli_query($conn,$query);
                while ($row=mysqli_fetch_assoc($result)) {?>
            <div class="col-md-6 col-xl-4">
              <article class="event-default-wrap">
                <div class="event-default">
                  <figure class="event-default-image"><img src="events_control_panel/images/<?php echo $row['event_image'] ?>" alt="" width="570" height="370"/>
                  </figure>
                  <div class="event-default-caption"><a class="button button-xs button-secondary button-nina" href="details.php?event_id=<?php echo $row['event_id'] ?>">More details</a></div>
                </div>
                <div class="event-default-inner">
                  <h5><a class="event-default-title" href="#"><?php echo $row['event_title'] ?></a></h5><span class="heading-5"><?php echo $row['user_name'] ?></span>
                </div>
              </article>
            </div>
       <?php } ?>
      
          </div>
        </div>
      </section>

    

   

 
<?php 
include_once("includes/footer.php");
?>