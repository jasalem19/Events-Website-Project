<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_POST['btn_user'])) {
    // CSRF token verification
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        echo "<script>alert('Invalid CSRF token. Please try again.');</script>";
        exit;
    }

    $user_name = $_POST['user_name'];
    $user_email = $_POST['user_email'];
    $user_address = $_POST['user_address'];
    $user_phone = $_POST['user_phone'];
    $user_password = $_POST['user_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate confirm password
    if ($user_password !== $confirm_password) {
        echo "<script>alert('Passwords do not match.')</script>";
    } else {
        // Server-side email validation
        if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
            echo "<script>alert('Invalid email format. Please enter a valid email.')</script>";
        } else {
            // Check if email already exists in the database
            $check_query = "SELECT * FROM users WHERE user_email = ?";
            if ($stmt = mysqli_prepare($conn, $check_query)) {
                mysqli_stmt_bind_param($stmt, "s", $user_email);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) > 0) {
                    echo "<script>alert('This email is already registered.')</script>";
                } else {
                    // Hash the password before storing it
                    $hashed_password = password_hash($user_password, PASSWORD_DEFAULT);

                    // Proceed with the registration process
                    $query = "INSERT INTO users(`user_name`, `user_email`, `user_address`, `user_phone`, `user_password`)
                              VALUES(?, ?, ?, ?, ?)";
                    if ($stmt = mysqli_prepare($conn, $query)) {
                        mysqli_stmt_bind_param($stmt, "sssss", $user_name, $user_email, $user_address, $user_phone, $hashed_password);
                        if (mysqli_stmt_execute($stmt)) {
                            echo "<script>alert('Your Account Has Been Registered Successfully.')</script>";
                            echo "<script>window.location.href='login.php';</script>";
                        } else {
                            echo "<script>alert('There was an error with the registration.')</script>";
                        }
                        mysqli_stmt_close($stmt);
                    } else {
                        echo "<script>alert('There was an error preparing the query.')</script>";
                    }
                }
                mysqli_stmt_close($stmt);
            } else {
                echo "<script>alert('There was an error preparing the query.')</script>";
            }
        }
    }
}
?>

<section class="section section-lg bg-default">
    <div class="container container-bigger">
        <div class="row row-50 justify-content-md-center align-items-lg-center justify-content-xl-between flex-lg-row-reverse">
            <div class="col-md-10 col-lg-12 col-xl-12">
                <form method="post" action="create_account.php" enctype="multipart/form-data" onsubmit="return validateForm()">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-name"></label>
                                <input class="form-input" id="form-1-name" type="text" name="user_name" placeholder="Full Name" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-email"></label>
                                <input class="form-input" id="form-1-email" type="email" name="user_email" placeholder="E-mail" required onkeyup="validateEmail()" />
                                <span id="email-error" style="color: red;"></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-address"></label>
                                <input class="form-input" id="form-1-address" type="text" name="user_address" placeholder="Address" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-phone"></label>
                                <input class="form-input" id="form-1-phone" pattern="[0-9]{10}" type="text" placeholder="Phone" name="user_phone" required />
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-password"></label>
                                <input class="form-input" type="password" name="user_password" placeholder="Password" id="password" onkeyup="validatePassword()" required />
                                <span id="password-error" style="color: red;"></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-wrap form-wrap-validation">
                                <label class="form-label-outside" for="form-1-confirm-password"></label>
                                <input class="form-input" type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" onkeyup="validateConfirmPassword()" required />
                                <span id="confirm-password-error" style="color: red;"></span>
                            </div>
                        </div>
                        <div class="col-sm-12 offset-custom-1">
                            <div class="form-button">
                                <button class="button button-secondary button-nina" style="background-color:#252525;" type="submit" name="btn_user">Register</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<script>
// Email validation
function validateEmail() {
    var email = document.getElementById("form-1-email").value;
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        document.getElementById("email-error").innerText = "Invalid email format.";
        return false;
    } else {
        document.getElementById("email-error").innerText = "";
        return true;
    }
}

// Validate the entire form
function validateForm() {
    return validateEmail() && validatePassword() && validateConfirmPassword();
}

function validatePassword() {
    var password = document.getElementById("password").value;

    // Check password
    if (password.length < 8) {
        document.getElementById("password-error").innerText = "Password must contain at least 8 characters.";
        return false;
    } else {
        document.getElementById("password-error").innerText = ""; // Remove error message

        // Check for symbol and uppercase letter in password
        var uppercase = /[A-Z]/;
        var symbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;

        if (!uppercase.test(password) || !symbol.test(password)) {
            document.getElementById("password-error").innerText = "The password must contain an uppercase letter and a symbol.";
            return false;
        } else {
            document.getElementById("password-error").innerText = ""; // Remove error message
        }
    }

    return true;
}

function validateConfirmPassword() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm_password").value;

    if (password !== confirmPassword) {
        document.getElementById("confirm-password-error").innerText = "Passwords do not match.";
        return false;
    } else {
        document.getElementById("confirm-password-error").innerText = "";
        return true;
    }
}
</script>

<?php
include_once("includes/footer.php");
?>
