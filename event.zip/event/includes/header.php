<!--suppresses error messages, and starts a session for user state management-->
<?php
include_once("includes/dbconn.php");
error_reporting(0);
session_start();
?>

<!DOCTYPE html>
<html class="wide wow-animation" lang="en"> 
  <head>
    <!-- Site Title-->
    <title>EventSpot</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="images/logo.png" type="image/x-icon">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Oswald:200,400%7CLato:300,400,300italic,700%7CMontserrat:900">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/fonts.css">
		
  </head>
  <body>
    <!-- Page preloader-->
    <div class="page-loader"> 
      <div class="page-loader-body"> 
        <div class="preloader-wrapper big active"> 
          <div class="spinner-layer spinner-blue"> 
            <div class="circle-clipper left">
              <div class="circle"> </div>
            </div>
            <div class="gap-patch">
              <div class="circle"> </div>
            </div>
            <div class="circle-clipper right">
              <div class="circle"></div>
            </div>
          </div>
          <div class="spinner-layer spinner-red">
            <div class="circle-clipper left">
              <div class="circle"></div>
            </div>
            <div class="gap-patch">
              <div class="circle"> </div>
            </div>
            <div class="circle-clipper right">
              <div class="circle"></div>
            </div>
          </div>
          <div class="spinner-layer spinner-yellow"> 
            <div class="circle-clipper left">
              <div class="circle"></div>
            </div>
            <div class="gap-patch">
              <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
              <div class="circle"> </div>
            </div>
          </div>
          <div class="spinner-layer spinner-green"> 
            <div class="circle-clipper left">
              <div class="circle"></div>
            </div>
            <div class="gap-patch">
              <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
              <div class="circle"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Page-->
    <div class="page">

      <!-- Page Header-->
      <header class="section page-header">
        <!-- RD Navbar-->
        <div class="rd-navbar-wrap rd-navbar-corporate">
          <nav class="rd-navbar" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-fullwidth" data-xl-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-fixed" data-xl-device-layout="rd-navbar-static" data-md-stick-up-offset="130px" data-lg-stick-up-offset="100px" data-stick-up="true" data-sm-stick-up="true" data-md-stick-up="true" data-lg-stick-up="true" data-xl-stick-up="true">
            <div class="rd-navbar-collapse-toggle" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
            <div class="rd-navbar-inner">
              <!-- RD Navbar Panel-->
              <div class="rd-navbar-panel">
                <!-- RD Navbar Toggle-->
                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                <!-- RD Navbar Brand-->
                <div class="rd-navbar-brand"><a class="brand-name" href="index.php"><img class="logo-default" src="images/logo.png" alt="" width="208" height="46"/><img class="logo-inverse" src="images/logo-inverse-208x46.png" alt="" width="208" height="46"/></a></div>
              </div>
              <div class="rd-navbar-aside-center">
                <div class="rd-navbar-nav-wrap">
                  <!-- RD Navbar Nav-->
                  <ul class="rd-navbar-nav">
                  <!--     <li class="active"><a href="index.php">Home</a></li> -->
                      <li class=""><a href="index.php">Home</a></li>
                      <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Help Center<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                          <li><a href="about_us.php">About us</a></li>
                          <li><a href="contacts.php">Contact</a></li>
                        </ul>
                      </i>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Category<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                          <?php
                            $query="select * from categories";
                            $result=mysqli_query($conn,$query);
                            while($row=mysqli_fetch_assoc($result)){
                          ?>
                          <li><a href="category.php?category_id=<?php echo $row['category_id']  ?>"><?php echo $row['category_name']  ?> </a></li>
                          <?php } ?>
                        </ul>
                      </li>
                      <li><a href="all_events.php"> Find Events</a></li>
                      <?php if ($_SESSION['user_id']) { ?>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php $query="select*from users where user_id={$_SESSION['user_id']}";
                          $result=mysqli_query($conn,$query);
                          $row=mysqli_fetch_assoc($result); 
                          echo $row['user_email'] ?>
                        <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                          <li><a href="profile.php">Profile</a></li>
                          <li><a href="events_control_panel/my_events.php">Created Events</a></li>
                          <li><a href="joined_events.php">Joined Events</a></li>
                          <li><a href="logout.php">Log out</a></li>
                        </ul>
                      </li>
                      <?php } else { ?>
                      <li><a href="login.php">Login</a></li>
                      <?php } ?>
                  </ul>
                </div>
              </div>

              <?php
                  if ($_SESSION['user_id']) {?>
                    <div class="rd-navbar-aside-right"><a class="button button-sm button-secondary button-nina" href="events_control_panel/create_event.php">Create +</a></div>
              <?php }else{ ?>
                    <div class="rd-navbar-aside-right"><a class="button button-sm button-secondary button-nina" href="create_account.php">Join us</a></div>
             <?php } ?>

            </div>
          </nav>
        </div>
</html>
      