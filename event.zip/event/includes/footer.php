      <!-- CTA Gradient-->
      <section class="section section-xs text-center bg-gray-700 novi-background bg-cover">
        <div class="container container-wide">
          <div class="box-cta-thin">
            <p class="big" style="font-family:'Fantasy'; word-spacing: 8px; letter-spacing: 1px; text-transform: capitalize;"><strong>EventSpot;  where courses become friendships</strong></p>
          </div>
        </div>
      </section>


      <!-- Footer Minimal-->
      <footer class="section page-footer page-footer-minimal novi-background bg-cover text-center bg-gray-darker">
        <div class="container container-wide">
          <div class="row row-fix justify-content-sm-center align-items-md-center row-30">
            <div class="col-md-10 col-lg-7 col-xl-4 text-xl-left"><a href="about-us.php"><img class="inverse-logo" src="images\logo.png" alt="" width="208" height="46"/></a></div>
            <div class="col-md-10 col-lg-7 col-xl-4">
              <p class="right">&#169;&nbsp;<span class="copyright-year"></span> EventSpot</p>
              <a href="about_us.php">About us</a>
              <a href ="#"> || </a>
              <a href="contacts.php">Contact</a>
            </div>
            <div class="col-md-10 col-lg-7 col-xl-4 text-xl-right">
             <p class="right">Follow Us</p>
              <ul class="group-xs group-middle"> 
                <li><a class="icon novi-icon icon-md-middle icon-circle icon-secondary-5-filled mdi mdi-facebook" href="#"></a></li>
                <li><a class="icon novi-icon icon-md-middle icon-circle icon-secondary-5-filled mdi mdi-twitter" href="#"></a></li>
                <li><a class="icon novi-icon icon-md-middle icon-circle icon-secondary-5-filled mdi mdi-instagram" href="#"></a></li>
                <li><a class="icon novi-icon icon-md-middle icon-circle icon-secondary-5-filled mdi mdi-linkedin" href="https://www.linkedin.com/in/jenans" target="_blank"></a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>

    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"> </div>
    
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>