<?php
// Function to sanitize input data
function sanitize_input($data) {
    $data = trim($data); // Remove whitespace
    $data = stripslashes($data); // Remove backslashes
    $data = htmlspecialchars($data); // Convert special characters to HTML entities
    return $data;
}

// Retrieve and sanitize form data
$name = sanitize_input($_POST['name']);
$email = sanitize_input($_POST['email']);
$phone = sanitize_input($_POST['phone']);
$message = sanitize_input($_POST['message']);

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo 'Invalid email format. Please enter a valid email address.';
    exit;
}

// Set recipient email address (change this to your desired email address)
$to = 'jasalem19@gmail.com';

// Subject of the email
$subject = 'Contact Form Submission';

// Construct the email body
$email_body = "Name: $name\n";
$email_body .= "Email: $email\n";
$email_body .= "Phone: $phone\n\n";
$email_body .= "Message:\n$message";

// Set headers
$headers = "From: $email\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

// Send email
$mail_sent = mail($to, $subject, $email_body, $headers);

// Check if mail sent successfully
if ($mail_sent) {
    echo 'Message sent successfully!';
} else {
    echo 'Message delivery failed... Please try again later.';
}
?>
