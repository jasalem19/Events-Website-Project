<?php
include_once("includes/dbconn.php");
error_reporting(0);
session_start();

$id=$_GET['delete_id'];
$query="delete  from events where event_id =$id";
mysqli_query($conn,$query);
echo "<script>alert('The data was deleted successfully.')</script>";

echo "<script> window.location.href='my_events.php';</script>";



?>