<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting(0);
session_start();

$UserID=  $_SESSION['user_id'];
if (isset($_POST['btn_save'])) {

  
  $event_title=$_POST['event_title'];
  $event_address=$_POST['event_address'];
  $event_description=$_POST['event_description'];
  $event_location=$_POST['event_location'];
  $event_start_time=$_POST['event_start_time'];
  $event_end_time=$_POST['event_end_time'];
  $event_capacity=$_POST['event_capacity'];
  $categories=$_POST['categories'];

  $image_name=$_FILES['images']['name'];
  $tmp_name=$_FILES['images']['tmp_name'];
  $path='images/'; 
  move_uploaded_file($tmp_name , $path.$image_name);

    $query="INSERT INTO events(`event_title`, `event_address`, `event_description`, `event_location`, `event_start_time`, `event_end_time`, `event_capacity`, `user_id`, `event_image`, `category_id`)
    VALUES('$event_title','$event_address', '$event_description', '$event_location', '$event_start_time', '$event_end_time', '$event_capacity', '$UserID', '$image_name','$categories')";
    mysqli_query($conn,$query);
    echo "<script>alert('The event was created successfully.')</script>";

    echo "<script> window.location.href='my_events.php';</script>";

}


?>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
              <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
               <center> <h6 class="text-white text-capitalize ps-3">My Events </h6></center>
              </div>
            </div>
            <div class="card-body px-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Title</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Description</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Address</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Location</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Start Time</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">End Time</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Capacity</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">category</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">image</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Attendee list</th>
                     

                    </tr>
                  </thead>
                  <tbody>
                  <?php
$query="select * from events JOIN categories where  events.user_id=$UserID AND  events.category_id =categories.category_id ";
$result=mysqli_query($conn,$query);

while ($row=mysqli_fetch_assoc($result)) {?>
                    <tr>
               
                  <td>
                        <div class="d-flex px-2 py-1">
                         
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="mb-0 text-sm"><?php echo $row['event_title']; ?></h6>
                          </div>
                        </div>
                      </td>
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['event_description']; ?></p>
                      </td>
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['event_address']; ?></p>
                      </td>
                      <td>
                        <p class="text-x font-weight-bold mb-0"><a href="<?php echo $row['event_location']; ?>">GPS</a></p>
                      </td>
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['event_start_time']; ?></p>
                      </td>
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['event_end_time']; ?></p>
                      </td>
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['event_capacity']; ?></p>
                      </td> 
                       <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['category_name']; ?></p>
                      </td>
                     
                      <td class="">
                        <span class="text-secondary text-x font-weight-bold"> <div>
                            <img src="images/<?php echo $row['event_image'] ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                          </div></span>
                      </td>
                      <td class="align-middle">
                        <a href="attendance_list.php?event_id=<?php echo $row['event_id']; ?>" class="text-secondary font-weight-bold text-x" data-toggle="tooltip" data-original-title="Edit user">
                        View  
                        </a>
                      </td>
                      <td class="align-middle">
                        <a href="edit_events.php?edit_id=<?php echo $row['event_id']; ?>" class="text-secondary font-weight-bold text-x" data-toggle="tooltip" data-original-title="Edit user">
                          Edit
                        </a>
                      </td>
                      <td class="align-middle">
                        <a href="delete_events.php?delete_id=<?php echo $row['event_id']; ?>" class="text-secondary font-weight-bold text-x" data-toggle="tooltip" data-original-title="Edit user">
                          Cancel
                        </a>
                      </td>
                    
                    </tr>
                    <?php } ?>
                        
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <?php
include_once("includes/footer.php");
    ?>