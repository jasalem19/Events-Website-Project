<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting(0);

$UserID = $_SESSION['user_id'];
$event_created = false; // Flag to check if event is successfully created

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $event_title = mysqli_real_escape_string($conn, $_POST['event_title']);
    $event_address = mysqli_real_escape_string($conn, $_POST['event_address']);
    $event_description = mysqli_real_escape_string($conn, $_POST['event_description']);
    $event_location = mysqli_real_escape_string($conn, $_POST['event_location']);
    $event_start_time = $_POST['event_start_time'];
    $event_end_time = $_POST['event_end_time'];
    $event_capacity = (int)$_POST['event_capacity'];
    $categories = (int)$_POST['categories'];

    // File upload handling
    $image_name = $_FILES['event_image']['name'];
    $tmp_name = $_FILES['event_image']['tmp_name'];
    $path = 'images/';
    move_uploaded_file($tmp_name, $path . $image_name);

    // Client-side validation using JavaScript for event capacity, start time, and end time
    echo "<script>";
    echo "function validateForm() {";
    echo "var eventCapacity = document.forms['eventForm']['event_capacity'].value;";
    echo "var eventStartTime = document.forms['eventForm']['event_start_time'].value;";
    echo "var eventEndTime = document.forms['eventForm']['event_end_time'].value;";
    echo "var currentDateTime = new Date().toISOString().slice(0,16);"; // Current date-time in YYYY-MM-DDTHH:mm format

    echo "if (eventCapacity < 1) {";
    echo "alert('Capacity must be at least 1.');";
    echo "return false;";
    echo "}";

    echo "if (eventStartTime < currentDateTime) {";
    echo "alert('Start time cannot be set before current time.');";
    echo "return false;";
    echo "}";

    echo "var fiveMinutesLater = new Date(new Date(eventStartTime).getTime() + 5 * 60000).toISOString().slice(0,16);";
    echo "if (eventEndTime <= eventStartTime || eventEndTime <= fiveMinutesLater) {";
    echo "alert('End time must be at least 5 minutes after start time.');";
    echo "return false;";
    echo "}";

    echo "return true;";
    echo "}";
    echo "</script>";

    // Server-side validation for event capacity, start time, and end time
    if ($event_capacity < 1) {
        echo "<script>alert('Capacity must be at least 1.')</script>";
    } elseif ($event_start_time < date('Y-m-d\TH:i', strtotime('now'))) {
        echo "<script>alert('Start time cannot be set before current time.')</script>";
    } else {
        $startTime = strtotime($event_start_time);
        $endTime = strtotime($event_end_time);
        $fiveMinutesLater = strtotime('+5 minutes', $startTime);

        if ($endTime <= $startTime || $endTime <= $fiveMinutesLater) {
            echo "<script>alert('End time must be at least 5 minutes after start time.')</script>";
        } else {
            // Format DATETIME fields
            $event_start_time = date('Y-m-d H:i:s', strtotime($event_start_time));
            $event_end_time = date('Y-m-d H:i:s', strtotime($event_end_time));

            // Insert query
            $query = "INSERT INTO events(`event_title`, `event_address`, `event_description`, `event_location`, `event_start_time`, `event_end_time`, `event_capacity`, `user_id`, `event_image`, `category_id`)
                      VALUES('$event_title', '$event_address', '$event_description', '$event_location', '$event_start_time', '$event_end_time', $event_capacity, '$UserID', '$path$image_name', $categories)";
            $result = mysqli_query($conn, $query);

            if ($result) {
                $event_created = true; // Flag event as successfully created
                echo "<script>alert('The event was created successfully.')</script>";
                echo "<script>window.location.href='my_events.php';</script>";
            } else {
                echo "<script>alert('Error: " . mysqli_error($conn) . "')</script>";
            }
        }
    }
}
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <center><h6 class="text-white text-capitalize ps-3">Create Event</h6></center>
                    </div>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="p-4 bg-light">
                        <form name="eventForm" action="#" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label">Title<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_title" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Address<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_address" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label">Description<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_description" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Location<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_location" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Start Time<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="datetime-local" class="form-control" name="event_start_time" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">End Time<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="datetime-local" class="form-control" name="event_end_time" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label">Maximum Capacity<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="number" class="form-control" name="event_capacity" placeholder="Enter Number" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Image Cover<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="file" class="form-control" name="event_image" required>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <label class="form-label">Category<span style="color:red"> *</span></label>
                                <div class="input-group input-group-outline my-3">  
                                    <select name="categories" class="form-control" required>
                                        <option value="">Select Category</option>
                                        <?php
                                        $query = "SELECT * FROM categories";
                                        $result = mysqli_query($conn, $query);
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo '<option value="' . $row['category_id'] . '">' . $row
                                            ['category_name'] . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <center>
                                <button class="btn btn-primary" type="submit" name="btn_save">Save</button>
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* CSS to hide spinners in number input */
    input[type="number"] {
        -moz-appearance: textfield;
        appearance: textfield;
    }
</style>

<?php
// Check if event creation was successful to prevent displaying the form again
if (!$event_created && $_SERVER["REQUEST_METHOD"] == "POST") {
    echo '<script>document.addEventListener("DOMContentLoaded", function () { validateForm(); });</script>';
}
?>

<?php include_once("includes/footer.php"); ?>
