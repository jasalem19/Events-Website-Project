<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting(0);
session_start();
$UserID=  $_SESSION['user_id'];
?>
      
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
              <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
               <center> <h6 class="text-white text-capitalize ps-3">Attendee List</h6></center>
              </div>
            </div>
            <div class="card-body px-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Title Event</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Attendee Name</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Attendee Phone</th>
                      <th class="text-uppercase text-secondary text-x font-weight-bolder ">Attendee Address</th>
                  
                     

                    </tr>
                  </thead>
                  <tbody>
                  <?php
$query="select * from events JOIN users JOIN tickets where  events.user_id=$UserID AND  events.event_id=tickets.event_id";
$result=mysqli_query($conn,$query);

while ($row=mysqli_fetch_assoc($result)) {?>
                    <tr>
               
                  <td>
                        <div class="d-flex px-2 py-1">
                         
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="mb-0 text-sm"><?php echo $row['event_title']; ?></h6>
                          </div>
                        </div>
                      </td>
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['user_name']; ?></p>
                      </td>
                    
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['user_phone']; ?></p>
                      </td>
                     
                      <td>
                        <p class="text-x font-weight-bold mb-0"><?php echo $row['user_address']; ?></p>
                      </td>
                    
                     
                     
                     
                    </tr>
                    <?php } ?>
                        
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <?php
include_once("includes/footer.php");
    ?>