<?php
$conn=mysqli_connect("localhost" , "root" , "" ,"events_management_system");
if (!$conn) {
	die("can not find connection");
}

mysqli_set_charset($conn , "utf8");



?>