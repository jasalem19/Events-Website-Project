<?php
include_once("includes/header.php");
include_once("includes/dbconn.php");
error_reporting(0);

$id = $_GET['edit_id'];

// Fetch event details for editing
$query = "SELECT * FROM events WHERE event_id = $id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if (isset($_POST['btn_save'])) {
    $event_title = $_POST['event_title'];
    $event_address = $_POST['event_address'];
    $event_description = $_POST['event_description'];
    $event_location = $_POST['event_location'];
    $event_start_time = $_POST['event_start_time'];
    $event_end_time = $_POST['event_end_time'];
    $event_capacity = $_POST['event_capacity'];
    $categories = $_POST['categories'];

    $errors = [];

    // Validate maximum capacity
    if ($event_capacity < 1) {
        $errors[] = "Maximum capacity must be at least 1.";
    }

    // Validate start time not before current time
    $current_time = date('Y-m-d\TH:i');
    if ($event_start_time < $current_time) {
        $errors[] = "Start time cannot be before the current time.";
    }

    // Validate end time at least 5 minutes after start time
    $start_timestamp = strtotime($event_start_time);
    $end_timestamp = strtotime($event_end_time);
    $min_end_timestamp = $start_timestamp + (5 * 60);
    if ($end_timestamp < $min_end_timestamp) {
        $errors[] = "End time must be at least 5 minutes after start time.";
    }

    if (empty($errors)) {
        $image_name = $_FILES['event_image']['name'];
        $tmp_name = $_FILES['event_image']['tmp_name'];
        $path = 'images/';
        
        if ($image_name) {
            move_uploaded_file($tmp_name, $path . $image_name);
            $image_update = ", event_image='$image_name'";
        } else {
            $image_update = "";
        }

        $query = "UPDATE events SET 
            event_title='$event_title',
            event_address='$event_address',
            event_description='$event_description',
            event_location='$event_location',
            event_start_time='$event_start_time',
            event_end_time='$event_end_time',
            event_capacity='$event_capacity',
            category_id='$categories'
            $image_update
            WHERE event_id = $id";
        
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Data was updated successfully.')</script>";
            echo "<script>window.location.href='my_events.php';</script>";
        } else {
            echo "<script>alert('Error updating event: " . mysqli_error($conn) . "')</script>";
        }
    } else {
        echo "<script>alert('" . implode("\\n", $errors) . "')</script>";
    }
}
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <center><h6 class="text-white text-capitalize ps-3">Edit Event</h6></center>
                    </div>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="p-4 bg-light">
                        <form action="#" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label">Title<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_title" value="<?php echo $row['event_title'] ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Address<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_address" value="<?php echo $row['event_address'] ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label">Description<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_description" value="<?php echo $row['event_description'] ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Location<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="text" class="form-control" name="event_location" value="<?php echo $row['event_location'] ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Start Time<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="datetime-local" class="form-control" name="event_start_time" value="<?php echo date('Y-m-d\TH:i', strtotime($row['event_start_time'])) ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">End Time<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="datetime-local" class="form-control" name="event_end_time" value="<?php echo date('Y-m-d\TH:i', strtotime($row['event_end_time'])) ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label">Maximum Capacity<span style="color:red"> *</span></label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="number" class="form-control" name="event_capacity" value="<?php echo $row['event_capacity'] ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Image Cover</label>
                                    <div class="input-group input-group-outline my-3">
                                        <input type="file" class="form-control" name="event_image">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label class="form-label">Categories<span style="color:red"> *</span></label>
                                <div class="input-group input-group-outline my-3">
                                    <select name="categories" id="" class="form-control" required>
                                        <option value="">Select Category</option>
                                        <?php
                                        $query = "SELECT * FROM categories";
                                        $result = mysqli_query($conn, $query);
                                        while ($cat_row = mysqli_fetch_assoc($result)) {
                                            $selected = ($cat_row['category_id'] == $row['category_id']) ? 'selected' : '';
                                            echo "<option value='{$cat_row['category_id']}' {$selected}>{$cat_row['category_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <center>
                                <button class="btn btn-primary" type="submit" name="btn_save">Update</button>
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    input[type="number"] {
        -moz-appearance: textfield;
        appearance: textfield;
    }

    input[type="number"]::-webkit-outer-spin-button,
    input[type="number"]::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
</style>

<script>
    function validateForm() {
        var title = document.querySelector('input[name="event_title"]').value.trim();
        var address = document.querySelector('input[name="event_address"]').value.trim();
        var description = document.querySelector('input[name="event_description"]').value.trim();
        var location = document.querySelector('input[name="event_location"]').value.trim();
        var startTime = document.querySelector('input[name="event_start_time"]').value.trim();
        var endTime = document.querySelector('input[name="event_end_time"]').value.trim();
        var capacity = document.querySelector('input[name="event_capacity"]').value.trim();
        var categories = document.querySelector('select[name="categories"]').value.trim();

        var errors = [];

        if (title === '') {
            errors.push('Title cannot be empty.');
        }
        if (address === '') {
            errors.push('Address cannot be empty.');
        }
        if (description === '') {
            errors.push('Description cannot be empty.');
        }
        if (location === '') {
            errors.push('Location cannot be empty.');
        }
        if (capacity < 1) {
            errors.push('Minimum capacity must be at least 1.');
        }

        var current_time = new Date().toISOString().slice(0, 16);
        if (startTime < current_time) {
            errors.push('Start time cannot be before the current time.');
        }

        var startTimestamp = new Date(startTime).getTime();
        var endTimestamp = new Date(endTime).getTime();
        var minEndTimestamp = startTimestamp + (5 * 60 * 1000);
        if (endTimestamp < minEndTimestamp) {
            errors.push('End time must be at least 5 minutes after start time.');
        }

        if (errors.length > 0) {
            alert(errors.join("\\n"));
            return false;
        }

        return true;
    }
</script>

<?php include_once("includes/footer.php"); ?>
