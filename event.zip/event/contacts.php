<?php
include_once("includes/dbconn.php");
include_once("includes/header.php");
error_reporting(0);
session_start();
?>
      <!-- Contact us-->
      <section class="section section-wrap bg-gray-lighter novi-background bg-cover">
        <div class="section-wrap-inner">
          <div class="container container-bigger">
            <div class="row row-fix row-50">
              <div class="col-lg-8 col-xl-7">
                <div class="section-wrap-content section-lg">
                  <h3>Contact us</h3>
                  <hr class="divider divider-left divider-secondary">
                  <p class="big">You can contact us any way that is convenient for you. We are available 24/7 via email. You can also use a quick contact form below.</p>
                  <!-- RD Mailform-->
                  <form class="rd-mailform" data-form-output="form-output-global" data-form-type="contact" method="post" action="contacts_msg.php">
                    <div class="row row-fix row-20">
                      <div class="col-md-6">
                        <div class="form-wrap form-wrap-validation">
                          <label class="form-label-outside" for="form-1-name">First name</label>
                          <input class="form-input" id="form-1-name" type="text" name="name" data-constraints="@Required"/>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-wrap form-wrap-validation">
                          <label class="form-label-outside" for="form-1-last-name">Last name</label>
                          <input class="form-input" id="form-1-last-name" type="text" name="last-name" data-constraints="@Required"/>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-wrap form-wrap-validation">
                          <label class="form-label-outside" for="form-1-email">E-mail</label>
                          <input class="form-input" id="form-1-email" type="email" name="email" data-constraints="@Email @Required"/>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-wrap form-wrap-validation">
                          <label class="form-label-outside" for="form-1-phone">Phone</label>
                          <input class="form-input" id="form-1-phone" type="text" name="phone" data-constraints="@Numeric @Required"/>
                        </div>
                      </div>
                      <div class="col-sm-12">
                        <div class="form-wrap form-wrap-validation">
                          <label class="form-label-outside" for="form-1-message">Message</label>
                          <textarea class="form-input" id="form-1-message" name="message" data-constraints="@Required"></textarea>
                        </div>
                      </div>
                      <div class="col-sm-12 offset-custom-1">
                        <div class="form-button">
                          <button class="button button-secondary button-nina" type="submit">send message</button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="section-wrap-aside">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d433869.38330790447!2d35.9476308!3d31.83576035!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151b5fb85d7981af%3A0x631c30c0f8dc65e8!2z2LnZhdmR2KfZhg!5e0!3m2!1sar!2sjo!4v1717253740601!5m2!1sar!2sjo" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </section>

      
<!-- Page Footer-->
<?php 
include_once("includes/footer.php");
?>